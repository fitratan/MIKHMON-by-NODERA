<?php
// NODERA Pay module disabled in offline APK
echo "<div class='main-container' style='display:block;'><div class='row'><div class='col-12'><div class='card'><div class='card-header'><h3>NODERA Pay</h3></div><div class='card-body pd-20 text-center'><p>La fonction NODERA Pay est désactivée dans cette version APK hors-ligne.</p><a href='./admin.php' class='btn bg-primary'><i class='fa fa-arrow-left'></i> Retour</a></div></div></div></div></div>";
