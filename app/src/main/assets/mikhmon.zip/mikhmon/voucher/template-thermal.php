<?php
// Load language variables
$thUserLang = $_SESSION['lang'] ?? $_COOKIE['mikhmon_lang'] ?? 'id';
if (file_exists('../lang/' . $thUserLang . '.php')) {
    include_once('../lang/' . $thUserLang . '.php');
} elseif (file_exists('./lang/' . $thUserLang . '.php')) {
    include_once('./lang/' . $thUserLang . '.php');
}

$vCfgPath = file_exists('../include/voucher_config.php') ? '../include/voucher_config.php' : (file_exists('./include/voucher_config.php') ? './include/voucher_config.php' : '');
if ($vCfgPath) { @include($vCfgPath); }
$thCfgItem = $voucher_config[$session] ?? null;
$vShowPrice = is_array($thCfgItem) ? (($thCfgItem['show_price'] ?? 'yes') !== 'no') : true;
$vShowValidity = is_array($thCfgItem) ? (($thCfgItem['show_validity'] ?? 'yes') !== 'no') : true;
$vShowDataLimit = is_array($thCfgItem) ? (($thCfgItem['show_datalimit'] ?? 'yes') !== 'no') : true;
$vShowLogo = is_array($thCfgItem) ? (($thCfgItem['show_logo'] ?? 'yes') !== 'no') : true;
$vShowHsName = is_array($thCfgItem) ? (($thCfgItem['show_hotspotname'] ?? 'yes') !== 'no') : true;
$vShowDns = is_array($thCfgItem) ? (($thCfgItem['show_dns'] ?? 'yes') !== 'no') : true;
$vShowNum = is_array($thCfgItem) ? (($thCfgItem['show_num'] ?? 'yes') !== 'no') : true;

$thProfile = !empty($profile) ? $profile : ($getuprofile ?? '');
$thValidity = !empty($validity) ? $validity : (!empty($timelimit) ? $timelimit : '');
if ($vShowDataLimit && !empty($datalimit)) {
    $thValidity = trim($thValidity . ' ' . $datalimit);
}
?>
<style>
.thermal-receipt-card {
  background: #ffffff;
  color: #111827;
  padding: 10px 12px;
  border: 1px solid #d1d5db;
  border-radius: 4px;
  text-align: center;
  font-family: 'Courier New', Courier, monospace;
  margin: 0 auto 12px auto;
  max-width: 270px;
  width: 100%;
  box-sizing: border-box;
  page-break-inside: avoid;
  box-shadow: 0 1px 4px rgba(0,0,0,0.06);
}
.thermal-receipt-card .th-dashed {
  border-top: 1px dashed #000000;
  margin: 6px 0;
}
.thermal-receipt-card .th-meta-row {
  font-size: 11px;
  text-align: left;
  margin-bottom: 2px;
  line-height: 1.35;
  padding: 0 2px;
}
.thermal-receipt-card .th-code-box {
  border: 2px solid #000000;
  padding: 5px;
  margin: 6px 0;
  background: #f8fafc;
  border-radius: 3px;
}
.thermal-receipt-card .th-code-val {
  font-size: 18px;
  font-weight: 900;
  letter-spacing: 2px;
  color: #000000;
  line-height: 1.2;
  word-break: break-all;
}
.thermal-receipt-card .v-th-qr canvas,
.thermal-receipt-card .v-th-qr .qrcode {
  width: 75px !important;
  height: 75px !important;
  margin: 0 auto;
  display: block;
}
@media print {
  @page {
    size: 58mm auto;
    margin: 0mm;
  }
  body {
    margin: 0 !important;
    padding: 0 !important;
    background: #fff !important;
  }
  .thermal-receipt-card {
    border: none !important;
    box-shadow: none !important;
    max-width: 58mm !important;
    width: 100% !important;
    margin: 0 auto !important;
    padding: 6px 2px !important;
    border-bottom: 1px dashed #000000 !important;
    page-break-inside: avoid !important;
    page-break-after: always !important;
  }
}
</style>

<div class="voucher v-thermal thermal-receipt-card">
  <?php if ($vShowLogo && !empty($logo)): ?>
    <div style="text-align: center; margin-bottom: 4px;">
      <img src="<?= $logo; ?>" alt="Logo" style="max-height: 38px; max-width: 130px; height: auto; object-fit: contain; margin: 0 auto; display: inline-block;">
    </div>
  <?php endif; ?>

  <?php if ($vShowHsName && !empty($hotspotname)): ?>
    <div style="font-weight: bold; font-size: 13px; line-height: 1.2; text-transform: uppercase;" class="v-th-title"><?= htmlspecialchars($hotspotname); ?></div>
  <?php endif; ?>

  <?php if ($vShowDns && !empty($dnsname)): ?>
    <div style="font-size: 10px; color: #4b5563;"><?= htmlspecialchars($dnsname); ?></div>
  <?php endif; ?>

  <div class="th-dashed"></div>

  <?php if (!empty($thProfile)): ?>
    <div class="th-meta-row">
      <?= $_package ?? 'Paket'; ?>: <b class="v-th-meta v-profile"><?= htmlspecialchars($thProfile); ?></b>
    </div>
  <?php endif; ?>

  <?php if ($vShowValidity && !empty($thValidity)): ?>
    <div class="th-meta-row">
      <?= $_validity ?? 'Masa Aktif'; ?>: <b class="v-th-validity"><?= htmlspecialchars($thValidity); ?></b>
    </div>
  <?php endif; ?>

  <?php if ($vShowPrice && !empty($price)): ?>
    <div class="th-meta-row" style="font-size: 12px; font-weight: bold;">
      <?= $_price ?? 'Harga'; ?>: <span class="v-th-price v-price"><?= htmlspecialchars($price); ?></span>
    </div>
  <?php endif; ?>

  <div class="th-code-box">
    <?php if ($usermode == "vc"): ?>
      <div style="font-size: 9px; text-transform: uppercase; letter-spacing: 0.5px; opacity: 0.85;"><?= $_voucher_code ?? 'Kode Voucher'; ?>:</div>
      <div class="th-code-val v-th-code v-code"><?= htmlspecialchars($username); ?></div>
      <div style="font-size: 8.5px; opacity: 0.8; margin-top: 2px;"><?= $_same_user_pass ?? 'Username &amp; Password sama'; ?></div>
    <?php else: ?>
      <div style="display: flex; justify-content: space-around; align-items: center;">
        <div style="text-align: center; flex: 1; border-right: 1px dashed #000; padding-right: 4px;">
          <div style="font-size: 8.5px; text-transform: uppercase; letter-spacing: 0.5px; opacity: 0.85;"><?= $_username_label ?? 'Username'; ?>:</div>
          <div style="font-size: 14px; font-weight: 900; color: #000;" class="v-th-code v-code"><?= htmlspecialchars($username); ?></div>
        </div>
        <div style="text-align: center; flex: 1; padding-left: 4px;">
          <div style="font-size: 8.5px; text-transform: uppercase; letter-spacing: 0.5px; opacity: 0.85;"><?= $_password_label ?? 'Password'; ?>:</div>
          <div style="font-size: 14px; font-weight: 900; color: #000;"><?= htmlspecialchars($password); ?></div>
        </div>
      </div>
    <?php endif; ?>
  </div>

  <?php if ($qr == "yes" || !empty($qrcode)): ?>
    <div style="margin-top: 4px;">
      <div class="v-th-qr"><?= $qrcode; ?></div>
      <div style="font-size: 8.5px; color: #4b5563; margin-top: 2px;"><?= $_scan_qr_to_login ?? 'Scan QR untuk Login Otomatis'; ?></div>
    </div>
  <?php endif; ?>

  <div class="th-dashed"></div>

  <div style="font-size: 10px; font-weight: bold;"><?= htmlspecialchars($hotspotname); ?></div>
  <div style="font-size: 9px; margin-top: 2px; color: #6b7280;"><?= $_thank_you_purchase ?? 'Terima kasih atas pembelian Anda'; ?></div>
</div>
