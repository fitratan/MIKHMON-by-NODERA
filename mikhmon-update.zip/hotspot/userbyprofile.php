<?php
/*
 *  Copyright (C) 2018 Laksamadi Guko.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// hide all error
error_reporting(0);
if (!isset($_SESSION["mikhmon"])) {
  header("Location:../admin.php?id=login");
} else {
// array color
  $color = array('1' => 'bg-blue', 'bg-indigo', 'bg-purple', 'bg-pink', 'bg-red', 'bg-yellow', 'bg-green', 'bg-teal', 'bg-cyan', 'bg-grey', 'bg-light-blue');

  // get user profile
  $getprofile = $API->comm("/ip/hotspot/user/profile/print");
  $getprofile = is_array($getprofile) ? $getprofile : array();
  $TotalReg = count($getprofile);

  // get user profile counts in 1 single lightweight query instead of N queries in loop
  $allusers = $API->comm("/ip/hotspot/user/print", array(".proplist" => "profile"));
  $allusers = is_array($allusers) ? $allusers : array();
  $total_all_users = count($allusers);
  $profile_counts = array();
  foreach ($allusers as $u) {
    $p = isset($u['profile']) ? $u['profile'] : '';
    $profile_counts[$p] = ($profile_counts[$p] ?? 0) + 1;
  }
  ?>
<div class="row">
<div class="col-12">
<div class="card">
<div class="card-header">
  <div class="card-header-flex">
    <h3 class="card-header-title">
      <i class="fa fa-users"></i> <?= $_vouchers ?>
    </h3>
    <div class="card-header-actions">
      <span onclick="location.reload();" class="header-action-btn pointer" title="Reload data"><i class="fa fa-refresh"></i></span>
    </div>
  </div>
</div>
<div class="card-body">
<div class="overflow" style="max-height: 80vh">	
<div class="row">	
      <div class="col-4">
        <div class="box bmh-75 box-bordered <?= $color[rand(1, 11)]; ?>">
          <div class="box-group">
            <div class="box-group-icon">
              <a title='Open User by profile <?= $pname; ?>'  href='./?hotspot=users&profile=all&session=<?= $session; ?>'>
              <i class="fa fa-ticket"></i></a>
            </div>
              <div class="box-group-area">
                <h3 >Profile : all<br>
                <?php $countuser = $total_all_users;
                if ($countuser < 2) {
                  echo $countuser . " Item";
                } elseif ($countuser > 1) {
                  echo $countuser . " Items";
                }
                ?></h3>

              <a title="Open User by profile all" href="./?hotspot=users&profile=all&session=<?= $session; ?>"><i class="fa fa-external-link"></i> <?= $_open ?></a>&nbsp;
              <a title="Generate User by profile <?= $pname; ?>" href="./?hotspot-user=generate&session=<?= $session; ?>"><i class="fa fa-users"></i> <?= $_generate ?></a>&nbsp;
              </div>
            </div>
            
          </div>
        </div>
<?php
for ($i = 0; $i < $TotalReg; $i++) {
  $profiledetalis = $getprofile[$i];
  $pname = $profiledetalis['name'];
  ?>
	     <div class="col-4">
        <div class="box bmh-75 box-bordered <?= $color[rand(1, 11)]; ?>">
          <div class="box-group">
            <div class="box-group-icon">
              <a title='Open User by profile <?= $pname; ?>'  href='./?hotspot=users&profile=<?= $pname; ?>&session=<?= $session; ?>'>
            	<i class="fa fa-ticket"></i></a>
            </div>
              <div class="box-group-area">
                <h3 >Profile : <?= $pname; ?><br>
                <?php	$countuser = isset($profile_counts[$pname]) ? $profile_counts[$pname] : 0;
                if ($countuser < 2) {
                  echo $countuser . " Item";
                } elseif ($countuser > 1) {
                  echo $countuser . " Items";
                }
                ?></h3>

              <a title="Open User by profile <?= $pname; ?>" href="./?hotspot=users&profile=<?= $pname; ?>&session=<?= $session; ?>"><i class="fa fa-external-link"></i> <?= $_open ?></a>&nbsp;
              <a title="Generate User by profile <?= $pname; ?>" href="./?hotspot-user=generate&genprof=<?= $pname; ?>&session=<?= $session; ?>"><i class="fa fa-users"></i> <?= $_generate ?></a>&nbsp;
              </div>
            </div>
            
          </div>
        </div>
        <?php 
      }
    } ?>
      </div>
    </div>
</div>
</div>
</div>
</div>